
function scrollToShop() {
  document.getElementById("shop").scrollIntoView({
    behavior: "smooth"
  });
}

document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();

  document.getElementById("message").innerText =
    "Thank you for contacting Universal Style!";
});
